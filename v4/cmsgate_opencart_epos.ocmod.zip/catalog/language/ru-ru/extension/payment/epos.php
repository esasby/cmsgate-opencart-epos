<?php

namespace cmsgate_scope_opencart_epos;

// Text
$_['heading_title'] = 'Ваш счет был успешно добавлен в систему ЕРИП! ';
