<?php

namespace cmsgate_scope_opencart_epos;

// Text
$_['heading_title'] = 'Your order has been successfully added to ERIP! ';
