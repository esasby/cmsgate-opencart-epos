<?php

namespace Opencart\Admin\Controller\Extension\CmsgateOpencartEpos\Payment;

use cmsgate_scope_opencart_epos\esas\cmsgate\opencart\AdminControllerExtensionPayment; // patched by scoper
require_once \dirname(__FILE__, 4) . '/system/library/esas/cmsgate/epos/init.php';

class Epos extends AdminControllerExtensionPayment
{
    public function index()
    {
        parent::index();
    }
}
