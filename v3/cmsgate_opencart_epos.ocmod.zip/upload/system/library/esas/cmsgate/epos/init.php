<?php

namespace cmsgate_scope_opencart_epos;

require_once \dirname(__FILE__) . '/vendor/esas/cmsgate-core/src/esas/cmsgate/CmsPlugin.php';
use cmsgate_scope_opencart_epos\esas\cmsgate\CmsPlugin;
use cmsgate_scope_opencart_epos\esas\cmsgate\epos\RegistryEposOpencart;

if (isset($this->registry)) {
    $GLOBALS['registry'] = $this->registry;
}
if (isset($registry)) {
    $GLOBALS['registry'] = $registry;
}

(new CmsPlugin(\dirname(__FILE__) . '/vendor', \dirname(__FILE__, 4)))->setRegistry(new RegistryEposOpencart())->init();
