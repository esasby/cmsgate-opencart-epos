<?php

namespace cmsgate_scope_opencart_epos;

\header('Content-Type: text/html; charset=utf-8');
require_once \dirname(\dirname(\dirname(\dirname(\dirname(__FILE__))))) . '/system/library/esas/cmsgate/epos/init.php';
use cmsgate_scope_opencart_epos\esas\cmsgate\epos\controllers\ControllerEposAddInvoice;
use cmsgate_scope_opencart_epos\esas\cmsgate\epos\controllers\ControllerEposCallback;
use cmsgate_scope_opencart_epos\esas\cmsgate\epos\controllers\ControllerEposCompletionPanel;
use cmsgate_scope_opencart_epos\esas\cmsgate\opencart\CatalogControllerExtensionPayment; // patched by scoper
use cmsgate_scope_opencart_epos\esas\cmsgate\epos\RegistryEposOpencart;
use cmsgate_scope_opencart_epos\esas\cmsgate\utils\Logger;
use cmsgate_scope_opencart_epos\esas\cmsgate\utils\OpencartVersion;
use cmsgate_scope_opencart_epos\esas\cmsgate\view\ViewBuilderOpencart;
use cmsgate_scope_opencart_epos\esas\cmsgate\wrappers\SystemSettingsWrapperOpencart;

class ControllerExtensionPaymentEpos extends CatalogControllerExtensionPayment
{
    public function index()
    {
        return parent::index();
    }
    /**
     * @param $data
     * @param $orderWrapper
     * @throws Throwable
     */
    protected function addPaySystemIndexData(&$data, $orderWrapper)
    {
        $data['confirmOrderForm'] = ViewBuilderOpencart::elementConfirmOrderForm($orderWrapper);
    }

    public function pay()
    {
        try {
            $orderId = $this->session->data['order_id'];
            if (!isset($orderId)) {
                $this->response->redirect(SystemSettingsWrapperOpencart::getInstance()->linkCatalogCheckout());
                return \false;
            }
            $orderWrapper = RegistryEposOpencart::getRegistry()->getOrderWrapper($orderId);
            // проверяем, привязан ли к заказу extId, если да,
            // то счет не выставляем, а просто прорисовываем старницу
            $invoiceJustAdded = false;
            if (empty($orderWrapper->getExtId())) {
                $controller = new ControllerEposAddInvoice();
                $controller->process($orderWrapper);
                $invoiceJustAdded = true;
            }
            $controller = new ControllerEposCompletionPanel();
            $completionPanel = $controller->process($orderId);
            // При успешном выставлении счёта очищаем корзину (как checkout/success),
            // чтобы товары не оставались в корзине и не давали оформить повторно.
            // order_id намеренно НЕ сбрасываем — он нужен для отображения страницы оплаты при перезагрузке.
            if ($invoiceJustAdded) {
                $this->cart->clear();
                unset($this->session->data['shipping_method']);
                unset($this->session->data['shipping_methods']);
                unset($this->session->data['payment_method']);
                unset($this->session->data['payment_methods']);
                unset($this->session->data['guest']);
                unset($this->session->data['comment']);
                unset($this->session->data['coupon']);
                unset($this->session->data['reward']);
                unset($this->session->data['voucher']);
                unset($this->session->data['vouchers']);
                unset($this->session->data['totals']);
            }
            $data['completionPanel'] = $completionPanel;
            $data['old_style'] = in_array(OpencartVersion::getVersion(), array(OpencartVersion::v2_1_x, OpencartVersion::v2_3_x, OpencartVersion::v3_x)) ? true : false;
            $this->document->setTitle($this->language->get('heading_title'));
            $this->addCommon($data);
            $this->addCheckoutContinueButton($data);
            $this->response->setOutput($this->load->view($this->getView("epos_checkout_success"), $data));
        } catch (\Throwable $e) {
            return $this->redirectFailure("pay", $e);
        } catch (\Exception $e) {
            // для совместимости с php 5
            return $this->redirectFailure("pay", $e);
        }
    }

    /**
     * Переопределено: при ошибке сервиса (напр. "счёт с таким номером уже существует")
     * возвращаем пользователя на оформление заказа с новым order_id и дружелюбным сообщением.
     */
    protected function redirectFailure($loggerName, $ex)
    {
        Logger::getLogger($loggerName)->error("Exception:", $ex);
        // Сбрасываем order_id, чтобы при повторном оформлении создался новый заказ
        // (новый уникальный number счёта), иначе сервис снова отклонит как неуникальный.
        unset($this->session->data['order_id']);
        // Дружелюбное сообщение вместо сырой ошибки сервиса.
        $this->session->data['error'] = 'Обратитесь к администратору сервиса';
        $url = SystemSettingsWrapperOpencart::getInstance()->linkCatalogCheckout();
        // ДИАГНОСТИКА: фиксируем, был ли вывод в поток до редиректа и откуда именно.
        $hsFile = ''; $hsLine = 0;
        $headersSent = headers_sent($hsFile, $hsLine);
        @file_put_contents(dirname(dirname(dirname(dirname(dirname(__FILE__))))).'/storage_oc3037/logs/redirect_diag.log',
            date('Y-m-d H:i:s') . ' epos headers_sent=' . ($headersSent ? "YES @ $hsFile:$hsLine" : 'NO')
            . ' ob_level=' . ob_get_level() . ' last_error=' . json_encode(error_get_last()) . "\n", FILE_APPEND);
        if (!$headersSent) {
            // Чистый путь: штатный 302-редирект.
            while (ob_get_level() > 0) {
                ob_end_clean();
            }
            $this->response->redirect($url);
        }
        // Headers уже отправлены (EPOS часто валит PHP-warnings в поток до catch) — 302 невозможен.
        // Делаем клиентский редирект через HTML, чтобы пользователь всё равно попал
        // на оформление заказа и увидел сообщение.
        echo '<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8">'
           . '<meta http-equiv="refresh" content="0; url=' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '">'
           . '<title>Перенаправление</title></head><body style="font-family:sans-serif;padding:24px">'
           . '<p>Обратитесь к администратору сервиса.</p>'
           . '<p><a href="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '">Перейти к оформлению заказа</a></p>'
           . '<script>window.location.replace(' . json_encode($url) . ');</script>'
           . '</body></html>';
        exit;
    }

    public function callback()
    {
        try {
            $controller = new ControllerEposCallback();
            $controller->process();
        } catch (\Throwable $e) {
            Logger::getLogger("callback")->error("Exception:", $e);
        } catch (\Exception $e) {
            // для совместимости с php 5
            Logger::getLogger("callback")->error("Exception:", $e);
        }
    }
}
\class_alias('cmsgate_scope_opencart_epos\\ControllerExtensionPaymentEpos', 'ControllerExtensionPaymentEpos', \false);
